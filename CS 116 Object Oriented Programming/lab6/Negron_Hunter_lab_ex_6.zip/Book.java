public class Book extends Record {

	public Book() {
	
		super();
	}
	
	public Book(String t, String a, String d) {
	
		super(t, a, d);
	}
	
	public String toString() {
	
		String str = super.toString();
		
		return str;
	}
}
