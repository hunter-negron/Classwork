package MainClass.OtherClasses;

public enum Conference {
	BIG10, 
	SE, 
	ACC, 
	BIG12, 
	PAC12, 
	AAC, 
	UNKNOWN
}
