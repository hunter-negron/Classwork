public interface SidedObject {

	public void displaySides();
}
