package Traffic.RoadNetwork;

public enum Color {

	GREEN,
	ORANGE,
	RED
};