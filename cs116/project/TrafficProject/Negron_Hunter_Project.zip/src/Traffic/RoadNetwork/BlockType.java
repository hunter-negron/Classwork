package Traffic.RoadNetwork;

public enum BlockType {

	NORMAL, 
	TRAFFIC, 
	INTERSECTION
};