package Traffic.RoadNetwork;

public enum Direction {

	// Order of Rights
	// Each direction is a right turn from the previous
	// Going backwards is the order of Lefts
	NORTH,
	 EAST,
	SOUTH,
	 WEST
};